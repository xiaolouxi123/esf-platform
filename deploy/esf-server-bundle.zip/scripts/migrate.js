#!/usr/bin/env node
'use strict';

/**
 * 建库 + 建表 + 建账号权限。幂等，可以反复跑。
 *
 * 用 root 连接（开发实例是空密码），执行 sql/*.sql，
 * 然后创建两个账号：
 *   esf_app   —— 应用账号，拥有 esf_platform 的全部权限
 *   esf_amxx  —— 游戏服务器账号，只能读白名单视图、消费 token、写在线时长
 */

const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const env = require('../src/env');

const SQL_DIR = path.join(__dirname, '..', 'sql');

function log(...args) {
  console.log('[migrate]', ...args);
}

/**
 * 用 root 连开发实例。
 * 开发实例初始化时只创建了 root@localhost，而 TCP 连接匹配不到它，
 * 所以本地走命名管道（DB_ROOT_SOCKET）；生产环境不设置该变量，直接 TCP + 密码。
 */
function rootConnectionOptions() {
  const base = {
    user: (process.env.DB_ROOT_USER || 'root').trim(),
    password: process.env.DB_ROOT_PASSWORD || '',
    multipleStatements: true,
    charset: 'utf8mb4',
  };
  const socket = (process.env.DB_ROOT_SOCKET || '').trim();
  if (socket) {
    return { ...base, socketPath: `\\\\.\\pipe\\${socket}` };
  }
  return { ...base, host: env.db.host, port: env.db.port };
}

async function createAccount(conn, user, host, password) {
  await conn.query('CREATE USER IF NOT EXISTS ?@? IDENTIFIED WITH mysql_native_password BY ?', [user, host, password]);
  await conn.query('ALTER USER ?@? IDENTIFIED WITH mysql_native_password BY ?', [user, host, password]);
  log(`账号就绪: '${user}'@'${host}' (mysql_native_password)`);
}

/**
 * 给已有库补列。CREATE TABLE IF NOT EXISTS 不会改动已存在的表，
 * 所以结构演进要靠这里（MySQL 8 的 ADD COLUMN 没有 IF NOT EXISTS）。
 */
async function ensureColumn(conn, dbName, table, column, definition) {
  const [rows] = await conn.query(
    `SELECT 1 FROM information_schema.columns
      WHERE table_schema = ? AND table_name = ? AND column_name = ? LIMIT 1`,
    [dbName, table, column]
  );
  if (rows.length > 0) return false;

  await conn.query(`ALTER TABLE \`${table}\` ADD COLUMN \`${column}\` ${definition}`);
  log(`已补列: ${table}.${column}`);
  return true;
}

async function main() {
  const conn = await mysql.createConnection(rootConnectionOptions());

  try {
    // 1. 结构 + 初始数据
    const files = fs
      .readdirSync(SQL_DIR)
      .filter((f) => f.endsWith('.sql'))
      .sort();

    for (const file of files) {
      const sql = fs.readFileSync(path.join(SQL_DIR, file), 'utf8');
      await conn.query(sql);
      log(`已执行 ${file}`);
    }

    // 2. 结构演进（给老库补列）
    await ensureColumn(
      conn,
      env.db.name,
      'launch_tokens',
      'authorized_until',
      'DATETIME NULL COMMENT "已在本服放行过的复用窗口" AFTER used_at'
    );
    await ensureColumn(
      conn,
      env.db.name,
      'launch_tokens',
      'purpose',
      "ENUM('join','spectate') NOT NULL DEFAULT 'join' COMMENT '连服用途' AFTER server_key"
    );
    await ensureColumn(
      conn,
      env.db.name,
      'users',
      'avatar',
      "VARCHAR(16) NOT NULL DEFAULT '' COMMENT '头像（emoji 或留空）' AFTER game_name"
    );
    await ensureColumn(
      conn,
      env.db.name,
      'users',
      'game_name_updated_at',
      "DATETIME NULL COMMENT '游戏昵称最近修改时间（自然日限改一次）' AFTER game_name"
    );
    await ensureColumn(
      conn,
      env.db.name,
      'users',
      'status_text',
      "VARCHAR(48) NULL COMMENT '自定义状态（Discord 式，最多 48 字）' AFTER combat_level"
    );
    // 资源封面（支持动图，原样保存）
    const coverColumns = [
      ['cover_name', 'VARCHAR(255) NULL AFTER sha256'],
      ['cover_mime', 'VARCHAR(64) NULL AFTER cover_name'],
      ['cover_size', 'INT UNSIGNED NULL AFTER cover_mime'],
      ['cover_sha256', 'CHAR(64) NULL AFTER cover_size'],
    ];
    for (const [column, definition] of coverColumns) {
      await ensureColumn(conn, env.db.name, 'assets', column, definition);
    }

    // 服务器模式（用于大厅分类）
    await ensureColumn(
      conn,
      env.db.name,
      'servers',
      'mode',
      "VARCHAR(24) NOT NULL DEFAULT '混战' AFTER port"
    );
    await conn.query(
      "UPDATE servers SET mode = '单挑' WHERE server_key = 'fcx-1v1-1' AND mode = '混战'"
    );
    await conn.query(
      "UPDATE servers SET mode = '新手' WHERE server_key = 'fcx-1v1-2' AND mode = '混战'"
    );

    // 约战房号按自然日重置：day_date + day_seq（唯一键防并发撞号）
    const addedDayDate = await ensureColumn(
      conn,
      env.db.name,
      'challenge_rooms',
      'day_date',
      'DATE NULL COMMENT "开房日期（房号按天重置）" AFTER id'
    );
    const addedDaySeq = await ensureColumn(
      conn,
      env.db.name,
      'challenge_rooms',
      'day_seq',
      'INT UNSIGNED NULL COMMENT "当天的第几号房" AFTER day_date'
    );
    if (addedDayDate || addedDaySeq) {
      const [rooms] = await conn.query(
        'SELECT id, created_at FROM challenge_rooms ORDER BY created_at ASC, id ASC'
      );
      const dayOf = (value) => {
        const at = value instanceof Date ? value : new Date(value);
        if (Number.isNaN(at.getTime())) return null;
        const pad = (n) => String(n).padStart(2, '0');
        return `${at.getFullYear()}-${pad(at.getMonth() + 1)}-${pad(at.getDate())}`;
      };
      const counters = new Map();
      for (const room of rooms) {
        const day = dayOf(room.created_at) || dayOf(new Date()) || '1970-01-01';
        const next = (counters.get(day) || 0) + 1;
        counters.set(day, next);
        await conn.query(
          'UPDATE challenge_rooms SET day_date = ?, day_seq = ? WHERE id = ?',
          [day, next, room.id]
        );
      }
      log(`已回填约战房号 day_date/day_seq（${rooms.length} 个房间）`);
    }
    const [daySeqIndex] = await conn.query(
      `SELECT 1 FROM information_schema.statistics
        WHERE table_schema = ? AND table_name = 'challenge_rooms'
          AND index_name = 'uniq_challenge_day_seq' LIMIT 1`,
      [env.db.name]
    );
    if (daySeqIndex.length === 0) {
      await conn.query(
        'ALTER TABLE challenge_rooms ADD UNIQUE KEY uniq_challenge_day_seq (day_date, day_seq)'
      );
      log('已加索引: challenge_rooms.uniq_challenge_day_seq');
    }

    // 头衔与自定义头像
    await ensureColumn(conn, env.db.name, 'users', 'avatar_url', 'MEDIUMTEXT NULL');
    await ensureColumn(conn, env.db.name, 'users', 'title_id', 'INT NULL AFTER role');
    await ensureColumn(
      conn,
      env.db.name,
      'users',
      'combat_level',
      "TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '格斗等级，0=未定级' AFTER title_id"
    );

    // 0.4.15 账号安全：邮箱绑定 / 登录锁定 / 强制改密
    await ensureColumn(
      conn,
      env.db.name,
      'users',
      'email',
      'VARCHAR(190) NULL COMMENT "绑定邮箱（找回密码用）" AFTER username'
    );
    await ensureColumn(conn, env.db.name, 'users', 'email_verified_at', 'DATETIME NULL AFTER email');
    await ensureColumn(
      conn,
      env.db.name,
      'users',
      'must_change_password',
      'TINYINT(1) NOT NULL DEFAULT 0 COMMENT "下次登录必须改密（管理员重置后置 1）"'
    );
    await ensureColumn(
      conn,
      env.db.name,
      'users',
      'failed_login_count',
      'INT UNSIGNED NOT NULL DEFAULT 0 COMMENT "连续登录失败次数"'
    );
    await ensureColumn(conn, env.db.name, 'users', 'locked_until', 'DATETIME NULL COMMENT "锁定截止时间"');

    // 0.4.16 第二批安全：TOTP 两步验证 + 设备会话
    await ensureColumn(
      conn,
      env.db.name,
      'users',
      'totp_secret',
      'VARCHAR(64) NULL COMMENT "TOTP 密钥（base32）" AFTER locked_until'
    );
    await ensureColumn(
      conn,
      env.db.name,
      'users',
      'totp_enabled',
      'TINYINT(1) NOT NULL DEFAULT 0 COMMENT "是否启用两步验证"'
    );
    await ensureColumn(conn, env.db.name, 'users', 'totp_backup_codes', 'TEXT NULL COMMENT "备用码哈希（JSON 数组）"');

    // 0.5.22 注销账号：软删除标记，列表与统计都排除
    await ensureColumn(conn, env.db.name, 'users', 'deleted_at', 'DATETIME NULL COMMENT "注销时间（软删除）"');
    await ensureColumn(conn, env.db.name, 'ranked_match_players', 'afk', 'TINYINT(1) NOT NULL DEFAULT 0');
    await ensureColumn(conn, env.db.name, 'challenge_player_stats', 'afk', 'TINYINT(1) NOT NULL DEFAULT 0');

    // 0.5.23 约战限时：默认 15 分钟一局
    await ensureColumn(
      conn,
      env.db.name,
      'challenge_rooms',
      'time_limit_sec',
      'INT UNSIGNED NOT NULL DEFAULT 900 COMMENT "单局时长上限（秒）"'
    );
    await conn.query(
      `CREATE TABLE IF NOT EXISTS user_sessions (
         id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         user_id BIGINT UNSIGNED NOT NULL,
         jti CHAR(32) NOT NULL,
         user_agent VARCHAR(255) NULL,
         ip VARCHAR(45) NULL,
         created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
         last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
         revoked_at DATETIME NULL,
         UNIQUE KEY uk_jti (jti),
         KEY idx_user (user_id, revoked_at),
         CONSTRAINT fk_session_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    );

    const emailIndex = await conn.query(
      `SELECT 1 FROM information_schema.statistics
        WHERE table_schema = ? AND table_name = 'users' AND index_name = 'uk_email' LIMIT 1`,
      [env.db.name]
    );
    if (emailIndex[0].length === 0) {
      await conn.query('ALTER TABLE users ADD UNIQUE KEY uk_email (email)');
      log('已加索引: users.uk_email');
    }

    // 金币钱包：在线/游戏时长按分钟结算
    await conn.query(
      `CREATE TABLE IF NOT EXISTS wallets (
         user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
         coins INT NOT NULL DEFAULT 0,
         total_earned INT NOT NULL DEFAULT 0,
         last_earned_at DATETIME NULL,
         updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         CONSTRAINT fk_wallet_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    );
    await conn.query(
      `CREATE TABLE IF NOT EXISTS coin_transactions (
         id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         user_id BIGINT UNSIGNED NOT NULL,
         amount INT NOT NULL,
         reason VARCHAR(32) NOT NULL,
         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
         INDEX idx_coin_user_time (user_id, created_at),
         CONSTRAINT fk_coin_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    );

    // 排位：档案、队列、比赛、座位、竞猜、观战
    await conn.query(
      `CREATE TABLE IF NOT EXISTS ranked_profiles (
         user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
         rating INT NOT NULL DEFAULT 1000,
         wins INT NOT NULL DEFAULT 0,
         losses INT NOT NULL DEFAULT 0,
         matches INT NOT NULL DEFAULT 0,
         updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         CONSTRAINT fk_ranked_profile_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    );
    await conn.query(
      `CREATE TABLE IF NOT EXISTS ranked_queue (
         id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         user_id BIGINT UNSIGNED NOT NULL UNIQUE,
         mode VARCHAR(8) NOT NULL,
         rating INT NOT NULL DEFAULT 1000,
         joined_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
         matched_match_id BIGINT UNSIGNED NULL,
         INDEX idx_ranked_queue_mode (mode, matched_match_id, joined_at)
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    );
    await conn.query(
      `CREATE TABLE IF NOT EXISTS ranked_matches (
         id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         mode VARCHAR(8) NOT NULL,
         server_key VARCHAR(32) NOT NULL,
         map VARCHAR(64) NULL,
         status ENUM('waiting','live','finished','cancelled') NOT NULL DEFAULT 'waiting',
         winner ENUM('a','b') NULL,
         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
         started_at DATETIME NULL,
         finished_at DATETIME NULL,
         INDEX idx_ranked_match_server (server_key, status)
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    );
    await conn.query(
      `CREATE TABLE IF NOT EXISTS ranked_match_players (
         match_id BIGINT UNSIGNED NOT NULL,
         user_id BIGINT UNSIGNED NOT NULL,
         team ENUM('a','b') NOT NULL,
         slot TINYINT UNSIGNED NOT NULL,
         ready TINYINT NOT NULL DEFAULT 0,
         rating_before INT NOT NULL DEFAULT 1000,
         rating_after INT NULL,
         PRIMARY KEY (match_id, user_id),
         UNIQUE KEY uk_ranked_seat (match_id, team, slot),
         CONSTRAINT fk_rmp_match FOREIGN KEY (match_id) REFERENCES ranked_matches(id) ON DELETE CASCADE,
         CONSTRAINT fk_rmp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    );
    await conn.query(
      `CREATE TABLE IF NOT EXISTS ranked_bets (
         id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         match_id BIGINT UNSIGNED NOT NULL,
         user_id BIGINT UNSIGNED NOT NULL,
         team ENUM('a','b') NOT NULL,
         amount INT NOT NULL,
         settled TINYINT NOT NULL DEFAULT 0,
         payout INT NOT NULL DEFAULT 0,
         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
         UNIQUE KEY uk_ranked_bet (match_id, user_id),
         CONSTRAINT fk_ranked_bet_match FOREIGN KEY (match_id) REFERENCES ranked_matches(id) ON DELETE CASCADE,
         CONSTRAINT fk_ranked_bet_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    );
    await conn.query(
      `CREATE TABLE IF NOT EXISTS ranked_spectators (
         match_id BIGINT UNSIGNED NOT NULL,
         user_id BIGINT UNSIGNED NOT NULL,
         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
         PRIMARY KEY (match_id, user_id),
         CONSTRAINT fk_spectate_match FOREIGN KEY (match_id) REFERENCES ranked_matches(id) ON DELETE CASCADE,
         CONSTRAINT fk_spectate_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    );

    // AMXX 比赛结束直接调用存储过程结算：ELO、战绩、竞猜派彩一次完成
    await conn.query('DROP PROCEDURE IF EXISTS settle_ranked_match');
    await conn.query(`
      CREATE PROCEDURE settle_ranked_match(IN p_match_id BIGINT UNSIGNED, IN p_winner VARCHAR(1))
      BEGIN
        DECLARE done INT DEFAULT 0;
        DECLARE v_user BIGINT UNSIGNED;
        DECLARE v_team VARCHAR(1);
        DECLARE v_rating INT;
        DECLARE v_after INT;
        DECLARE v_afk TINYINT DEFAULT 0;
        DECLARE total_pool INT DEFAULT 0;
        DECLARE winning_pool INT DEFAULT 0;
        DECLARE cur CURSOR FOR
          SELECT user_id, team, rating_before, afk FROM ranked_match_players WHERE match_id = p_match_id;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

        UPDATE ranked_matches
           SET status = 'finished', winner = p_winner, finished_at = NOW()
         WHERE id = p_match_id AND status IN ('waiting','live');

        OPEN cur;
        player_loop: LOOP
          FETCH cur INTO v_user, v_team, v_rating, v_afk;
          IF done THEN LEAVE player_loop; END IF;
          IF v_team = p_winner THEN
            SET v_after = v_rating + 25;
          ELSEIF v_afk = 1 THEN
            SET v_after = GREATEST(0, v_rating - 30);
          ELSE
            SET v_after = GREATEST(0, v_rating - 20);
          END IF;
          UPDATE ranked_match_players SET rating_after = v_after
           WHERE match_id = p_match_id AND user_id = v_user;
          INSERT IGNORE INTO ranked_profiles (user_id, rating) VALUES (v_user, v_rating);
          UPDATE ranked_profiles
             SET rating = v_after,
                 wins = wins + IF(v_team = p_winner, 1, 0),
                 losses = losses + IF(v_team = p_winner, 0, 1),
                 matches = matches + 1
           WHERE user_id = v_user;
        END LOOP;
        CLOSE cur;

        SELECT COALESCE(SUM(amount), 0) INTO total_pool
          FROM ranked_bets WHERE match_id = p_match_id AND settled = 0;
        SELECT COALESCE(SUM(CASE WHEN team = p_winner THEN amount ELSE 0 END), 0) INTO winning_pool
          FROM ranked_bets WHERE match_id = p_match_id AND settled = 0;

        IF winning_pool = 0 THEN
          INSERT IGNORE INTO wallets (user_id)
            SELECT user_id FROM ranked_bets WHERE match_id = p_match_id AND settled = 0;
          UPDATE wallets w JOIN ranked_bets b ON b.user_id = w.user_id
             SET w.coins = w.coins + b.amount
           WHERE b.match_id = p_match_id AND b.settled = 0;
          INSERT INTO coin_transactions (user_id, amount, reason)
            SELECT user_id, amount, 'ranked_refund'
              FROM ranked_bets WHERE match_id = p_match_id AND settled = 0;
          UPDATE ranked_bets SET settled = 1, payout = amount
           WHERE match_id = p_match_id AND settled = 0;
        ELSE
          INSERT IGNORE INTO wallets (user_id)
            SELECT user_id FROM ranked_bets WHERE match_id = p_match_id AND settled = 0;
          UPDATE wallets w JOIN ranked_bets b ON b.user_id = w.user_id
             SET w.coins = w.coins + FLOOR(b.amount * total_pool * 0.95 / winning_pool)
           WHERE b.match_id = p_match_id AND b.settled = 0 AND b.team = p_winner;
          INSERT INTO coin_transactions (user_id, amount, reason)
            SELECT user_id, FLOOR(amount * total_pool * 0.95 / winning_pool), 'ranked_win'
              FROM ranked_bets WHERE match_id = p_match_id AND settled = 0 AND team = p_winner;
          UPDATE ranked_bets
             SET settled = 1,
                 payout = IF(team = p_winner, FLOOR(amount * total_pool * 0.95 / winning_pool), 0)
           WHERE match_id = p_match_id AND settled = 0;
        END IF;
      END
    `);
    await conn.query('DROP PROCEDURE IF EXISTS settle_challenge_match');
    await conn.query(`
      CREATE PROCEDURE settle_challenge_match(
        IN p_room_id BIGINT UNSIGNED,
        IN p_winner VARCHAR(1),
        IN p_score_a INT,
        IN p_score_b INT,
        IN p_victory_type VARCHAR(8),
        IN p_limit INT
      )
      BEGIN
        INSERT INTO challenge_results
          (room_id, winner, score_a, score_b, victory_type, victory_limit, ended_at)
        VALUES (p_room_id, p_winner, p_score_a, p_score_b, p_victory_type, p_limit, NOW())
        ON DUPLICATE KEY UPDATE
          winner = VALUES(winner),
          score_a = VALUES(score_a),
          score_b = VALUES(score_b),
          victory_type = VALUES(victory_type),
          victory_limit = VALUES(victory_limit),
          ended_at = VALUES(ended_at);
        UPDATE challenge_rooms
           SET status = 'closed', closed_at = NOW()
         WHERE id = p_room_id AND status = 'live';
      END
    `);
    await conn.query(
      `CREATE TABLE IF NOT EXISTS titles (
         id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         name VARCHAR(24) NOT NULL UNIQUE,
         color CHAR(7) NOT NULL DEFAULT '#94A0B8',
         sort_rank INT NOT NULL DEFAULT 0,
         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    );
    const seedTitles = [
      ['所有者', '#FF8A1F', 100, 'owner'],
      ['管理员', '#FF5F6D', 80, 'admin'],
      ['运营', '#3FD0FF', 60, 'ops'],
      ['作者', '#A78BFA', 40, 'creator'],
      ['玩家', '#94A0B8', 10, 'user'],
    ];
    for (const [name, color, rank] of seedTitles) {
      await conn.query('INSERT IGNORE INTO titles (name, color, sort_rank) VALUES (?, ?, ?)', [
        name,
        color,
        rank,
      ]);
    }
    for (const [name, , , role] of seedTitles) {
      await conn.query(
        `UPDATE users u JOIN titles t ON t.name = ?
            SET u.title_id = t.id
          WHERE u.role = ? AND u.title_id IS NULL`,
        [name, role]
      );
    }

    // 3. 应用账号
    await createAccount(conn, env.db.user, env.db.allowedHost, env.db.password);
    await conn.query(`GRANT ALL PRIVILEGES ON \`${env.db.name}\`.* TO ?@?`, [
      env.db.user,
      env.db.allowedHost,
    ]);

    // 3. 游戏服务器账号：最小权限
    await createAccount(conn, env.amxx.user, env.amxx.allowedHost, env.amxx.password);
    const db = `\`${env.db.name}\``;
    const grants = [
      `GRANT SELECT ON ${db}.\`v_platform_users\` TO ?@?`,
      `GRANT SELECT, UPDATE ON ${db}.\`launch_tokens\` TO ?@?`,
      `GRANT SELECT, INSERT, UPDATE ON ${db}.\`play_sessions\` TO ?@?`,
      `GRANT SELECT ON ${db}.\`servers\` TO ?@?`,
      `GRANT SELECT ON ${db}.\`ranked_matches\` TO ?@?`,
      `GRANT SELECT ON ${db}.\`ranked_match_players\` TO ?@?`,
      `GRANT EXECUTE ON PROCEDURE ${db}.settle_ranked_match TO ?@?`,
      `GRANT SELECT ON ${db}.\`challenge_rooms\` TO ?@?`,
      `GRANT SELECT ON ${db}.\`challenge_room_players\` TO ?@?`,
      `GRANT SELECT ON ${db}.\`challenge_configs\` TO ?@?`,
      `GRANT SELECT, INSERT, UPDATE ON ${db}.\`challenge_player_stats\` TO ?@?`,
      `GRANT SELECT, INSERT, UPDATE, DELETE ON ${db}.\`amxx_builds\` TO ?@?`,
      `GRANT EXECUTE ON PROCEDURE ${db}.settle_challenge_match TO ?@?`,
    ];
    // 游戏服务器可能早于本次迁移创建过 'esf_amxx'@'<公网IP>' 账号；
    // 只授权 allowedHost 会让这些账号缺新表权限，锁服/约战查询直接报 SELECT denied。
    const amxxHosts = new Set([env.amxx.allowedHost]);
    try {
      const [amxxRows] = await conn.query('SELECT Host FROM mysql.user WHERE User = ?', [
        env.amxx.user,
      ]);
      for (const row of amxxRows) amxxHosts.add(row.Host);
    } catch (err) {
      log(`[warn] 无法枚举 ${env.amxx.user} 的已有主机，只授权 ${env.amxx.allowedHost}：${err.message}`);
    }
    for (const host of amxxHosts) {
      for (const grant of grants) {
        await conn.query(grant, [env.amxx.user, host]);
      }
    }
    log(
      `已授予 '${env.amxx.user}' 最小权限（白名单视图 + token 消费 + 在线时长；主机数 ${amxxHosts.size}）`
    );

    // 4. 汇总
    const [[{ tables }]] = await conn.query(
      'SELECT COUNT(*) AS tables FROM information_schema.tables WHERE table_schema = ? AND table_type = ?',
      [env.db.name, 'BASE TABLE']
    );
    const [[{ servers }]] = await conn.query(`SELECT COUNT(*) AS servers FROM ${db}.servers`);

    log(`完成：${tables} 张表，${servers} 台服务器`);
    log(`应用账号 : ${env.db.user}@${env.db.host}:${env.db.port}/${env.db.name}`);
    log(`AMXX账号 : ${env.amxx.user}@${env.amxx.allowedHost}`);
  } finally {
    await conn.end();
  }
}

main().catch((err) => {
  console.error('[migrate] 失败:', err.message);
  if (err.code === 'ECONNREFUSED') {
    console.error('[migrate] 数据库没起来？先执行: npm run db:start');
  }
  process.exit(1);
});
