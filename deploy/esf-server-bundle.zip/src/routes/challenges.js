'use strict';

const express = require('express');
const { z } = require('zod');

const { requireAuth } = require('../middleware/auth');
const { badRequest } = require('../lib/errors');
const challenges = require('../services/challenges');

const router = express.Router();

function idOf(value) {
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id <= 0) throw badRequest('房间 ID 不合法');
  return id;
}

function fail(err, next) {
  next(err.status ? err : badRequest(err.message));
}

router.use('/challenges', requireAuth);

router.get('/challenges', async (req, res, next) => {
  try {
    res.json({ ok: true, data: await challenges.getState(req.user.id) });
  } catch (err) {
    fail(err, next);
  }
});

const createSchema = z.object({
  title: z.string().trim().max(48).optional(),
  mode: z.enum(challenges.MODES),
  map: z.string().trim().max(64).optional(),
  serverKey: z.string().trim().min(1).max(32),
  victoryType: z.enum(['kills', 'deaths']).default('kills'),
  victoryLimit: z.coerce.number().int().min(3).max(50).default(10),
});

router.post('/challenges', async (req, res, next) => {
  try {
    const body = createSchema.parse(req.body || {});
    const room = await challenges.createRoom(
      { id: req.user.id, username: req.user.username, gameName: req.user.game_name },
      body
    );
    res.status(201).json({ ok: true, data: { room, state: await challenges.getState(req.user.id) } });
  } catch (err) {
    fail(err, next);
  }
});

router.post('/challenges/:id/join', async (req, res, next) => {
  try {
    const room = await challenges.joinRoom(req.user.id, idOf(req.params.id));
    res.json({ ok: true, data: { room, state: await challenges.getState(req.user.id) } });
  } catch (err) {
    fail(err, next);
  }
});

router.post('/challenges/:id/leave', async (req, res, next) => {
  try {
    await challenges.leaveRoom(req.user.id, idOf(req.params.id));
    res.json({ ok: true, data: await challenges.getState(req.user.id) });
  } catch (err) {
    fail(err, next);
  }
});

router.post('/challenges/:id/close', async (req, res, next) => {
  try {
    await challenges.closeRoom(req.user, idOf(req.params.id));
    res.json({ ok: true, data: await challenges.getState(req.user.id) });
  } catch (err) {
    fail(err, next);
  }
});

const inviteSchema = z.object({
  userId: z.coerce.number().int().positive(),
});

router.post('/challenges/:id/invite', async (req, res, next) => {
  try {
    const body = inviteSchema.parse(req.body || {});
    await challenges.invite(req.user, idOf(req.params.id), body.userId);
    res.json({ ok: true, data: { invited: true, room: await challenges.getRoom(idOf(req.params.id), req.user.id) } });
  } catch (err) {
    fail(err, next);
  }
});

const respondSchema = z.object({
  action: z.enum(['accept', 'decline']),
});

router.post('/challenges/invites/:id/respond', async (req, res, next) => {
  try {
    const body = respondSchema.parse(req.body || {});
    const result = await challenges.respond(req.user.id, idOf(req.params.id), body.action);
    res.json({ ok: true, data: { ...result, state: await challenges.getState(req.user.id) } });
  } catch (err) {
    fail(err, next);
  }
});

const readySchema = z.object({
  ready: z.boolean().default(true),
});

router.post('/challenges/:id/ready', async (req, res, next) => {
  try {
    const body = readySchema.parse(req.body || {});
    const room = await challenges.setReady(req.user.id, idOf(req.params.id), body.ready);
    res.json({ ok: true, data: { room } });
  } catch (err) {
    fail(err, next);
  }
});

router.post('/challenges/:id/start', async (req, res, next) => {
  try {
    const room = await challenges.startRoom(req.user, idOf(req.params.id));
    res.json({ ok: true, data: { room, state: await challenges.getState(req.user.id) } });
  } catch (err) {
    fail(err, next);
  }
});

router.get('/challenges/:id/result', async (req, res, next) => {
  try {
    const result = await challenges.resultOf(idOf(req.params.id));
    if (!result) throw badRequest('约战结果不存在');
    res.json({ ok: true, data: { result } });
  } catch (err) {
    fail(err, next);
  }
});

router.post('/challenges/:id/spectate', async (req, res, next) => {
  try {
    const data = await challenges.joinSpectate(req.user.id, idOf(req.params.id));
    res.status(201).json({ ok: true, data });
  } catch (err) {
    fail(err, next);
  }
});

router.delete('/challenges/:id/spectate', async (req, res, next) => {
  try {
    const data = await challenges.leaveSpectate(req.user.id, idOf(req.params.id));
    res.json({ ok: true, data });
  } catch (err) {
    fail(err, next);
  }
});

const queueSchema = z.object({
  serverKey: z.string().trim().min(1).max(32),
  kind: z.enum(['ranked', 'challenge']).optional(),
});

router.get('/queue', requireAuth, async (req, res, next) => {
  try {
    const data = await challenges.queueList(String(req.query.serverKey || ''), req.user.id);
    res.json({ ok: true, data });
  } catch (err) {
    fail(err, next);
  }
});

router.post('/queue', requireAuth, async (req, res, next) => {
  try {
    const body = queueSchema.parse(req.body || {});
    const data = await challenges.joinQueue(req.user.id, body.serverKey, body.kind);
    res.status(201).json({ ok: true, data });
  } catch (err) {
    fail(err, next);
  }
});

router.delete('/queue', requireAuth, async (req, res, next) => {
  try {
    const data = await challenges.leaveQueue(req.user.id, String(req.query.serverKey || ''));
    res.json({ ok: true, data });
  } catch (err) {
    fail(err, next);
  }
});

module.exports = router;
