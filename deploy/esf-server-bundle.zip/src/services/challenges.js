'use strict';

/**
 * 约战房间。
 *
 * 和排位是两套东西：
 *   - 排位由队列/评分/结算驱动，会锁服；
 *   - 约战只是“把一桌人约到一起”，不计分，但开赛后锁服；房主可以指定一张图/一台服。
 *
 * 所有写操作都用事务 + SELECT ... FOR UPDATE 防重复进房/超员。
 */

const bcrypt = require('bcryptjs');

const { pool, q, one } = require('../db');
const { badRequest, forbidden, notFound, conflict } = require('../lib/errors');

const MODE_SLOTS = { '1v1': 1, '2v2': 2 };
const MODES = Object.keys(MODE_SLOTS);
const VICTORY_TYPES = ['kills', 'deaths'];
const VICTORY_LIMITS = [3, 5, 10];
const CHALLENGE_TIME_LIMIT_SEC = 900;
const CHALLENGE_TIME_GRACE_SEC = 180;
const SPECTATOR_LIMIT = 4;
const EMPTY_ROOM_TIMEOUT_SEC = 600;
const READY_TIMEOUT_SEC = 120;
const STALE_HOURS = 6;

function publicUser(row) {
  return {
    id: Number(row.id),
    username: row.username,
    gameName: row.game_name,
    avatar: row.avatar || '',
    avatarUrl: row.avatar_url || '',
    role: row.role,
    combatLevel: Number(row.combat_level || 0),
  };
}

function normalizeMode(mode) {
  const value = String(mode || '');
  if (!MODES.includes(value)) throw badRequest('约战模式只能是 1v1 / 2v2');
  return value;
}

function normalizeTitle(title, fallback) {
  const value = String(title || '').trim();
  if (!value) return fallback;
  if (value.length < 2 || value.length > 48) throw badRequest('房间名需要 2-48 个字');
  return value;
}

function normalizeMap(map) {
  const value = String(map || '').trim();
  if (!value) return null;
  if (value.length > 64) throw badRequest('地图名太长');
  return value;
}

function normalizeBestOf(value) {
  return Number(value) === 1 ? 1 : 3;
}

function normalizeRoomPassword(value) {
  const password = String(value || '');
  if (password.length < 4 || password.length > 32) throw badRequest('私密房密码需要 4-32 位');
  return password;
}

function normalizeVictoryType(type) {
  const value = String(type || 'kills');
  if (!VICTORY_TYPES.includes(value)) throw badRequest('胜利条件只能是击杀数或死亡数');
  return value;
}

function normalizeVictoryLimit(limit) {
  const value = Number(limit);
  if (!VICTORY_LIMITS.includes(value)) {
    throw badRequest('胜利目标只能是 3 / 5 / 10 次');
  }
  return value;
}

function victoryLabel(type, limit) {
  if (type === 'series') return Number(limit) <= 1 ? '一局定胜负' : '三局两胜';
  return type === 'deaths' ? `死亡 ${limit} 次` : `击杀 ${limit} 人`;
}

function roomRow(id) {
  return one(
    `SELECT r.*, u.username AS host_username, u.game_name AS host_game_name,
            u.avatar AS host_avatar, u.avatar_url AS host_avatar_url,
            u.role AS host_role, u.combat_level AS host_combat_level,
            s.name AS server_name, s.ip AS server_ip, s.port AS server_port,
            c.victory_type, c.victory_limit,
            res.winner AS result_winner, res.score_a AS result_score_a,
            res.score_b AS result_score_b, res.ended_at AS result_ended_at
       FROM challenge_rooms r
       JOIN users u ON u.id = r.host_id
       LEFT JOIN servers s ON s.server_key = r.server_key
       LEFT JOIN challenge_configs c ON c.room_id = r.id
       LEFT JOIN challenge_results res ON res.room_id = r.id
      WHERE r.id = ?
      LIMIT 1`,
    [id]
  );
}

async function roomMembers(roomId) {
  const rows = await q(
    `SELECT p.team, p.ready, p.joined_at,
            u.id, u.username, u.game_name, u.avatar, u.avatar_url,
            u.role, u.combat_level,
            COALESCE(st.kills, 0) AS kills, COALESCE(st.deaths, 0) AS deaths
       FROM challenge_room_players p
       JOIN users u ON u.id = p.user_id
       LEFT JOIN challenge_player_stats st ON st.room_id = p.room_id AND st.user_id = p.user_id
      WHERE p.room_id = ?
      ORDER BY p.joined_at ASC, p.user_id ASC`,
    [roomId]
  );
  return rows.map((row) => ({
    ...publicUser(row),
    team: row.team,
    ready: Boolean(row.ready),
    joinedAt: row.joined_at,
    kills: Number(row.kills || 0),
    deaths: Number(row.deaths || 0),
  }));
}

async function pendingInvites(roomId) {
  const rows = await q(
    `SELECT i.id, i.created_at, u.id AS user_id, u.username, u.game_name, u.avatar, u.avatar_url, u.role
       FROM challenge_invites i
       JOIN users u ON u.id = i.to_user_id
      WHERE i.room_id = ? AND i.status = 'pending'
      ORDER BY i.id ASC`,
    [roomId]
  );
  return rows.map((row) => ({
    id: Number(row.id),
    user: publicUser({
      id: row.user_id,
      username: row.username,
      game_name: row.game_name,
      avatar: row.avatar,
      avatar_url: row.avatar_url,
      role: row.role,
      combat_level: 0,
    }),
    createdAt: row.created_at,
  }));
}

function serverOf(row) {
  if (!row.server_key || !row.server_ip) return null;
  return {
    serverKey: row.server_key,
    name: row.server_name || row.server_key,
    ip: row.server_ip,
    port: Number(row.server_port),
  };
}

function roomBase(row) {
  return {
    id: Number(row.id),
    displayNo: row.day_seq ? Number(row.day_seq) : Number(row.id),
    dayDate: row.day_date || null,
    title: row.title,
    mode: row.mode,
    map: row.map || null,
    serverKey: row.server_key || null,
    server: serverOf(row),
    isPrivate: Boolean(Number(row.is_private || 0)),
    status: row.status,
    roundNo: Number(row.round_no || 1),
    bestOf: Number(row.best_of || 3) === 1 ? 1 : 3,
    maxRounds: Number(row.best_of || 3) === 1 ? 1 : 3,
    maxPlayers: Number(row.max_players),
    victoryType: row.victory_type || 'kills',
    victoryLimit: Number(row.victory_limit || 10),
    victoryLabel: victoryLabel(row.victory_type || 'kills', Number(row.victory_limit || 10)),
    result: row.result_winner
      ? {
          winner: row.result_winner,
          scoreA: Number(row.result_score_a || 0),
          scoreB: Number(row.result_score_b || 0),
          endedAt: row.result_ended_at,
        }
      : null,
    createdAt: row.created_at,
    startedAt: row.started_at || null,
    timeLimitSec: Number(row.time_limit_sec || CHALLENGE_TIME_LIMIT_SEC),
    endsAt:
      row.started_at && row.status === 'live'
        ? new Date(new Date(row.started_at).getTime() + Number(row.time_limit_sec || CHALLENGE_TIME_LIMIT_SEC) * 1000)
        : null,
    closedAt: row.closed_at || null,
    updatedAt: row.updated_at || null,
    host: publicUser({
      id: row.host_id,
      username: row.host_username,
      game_name: row.host_game_name,
      avatar: row.host_avatar,
      avatar_url: row.host_avatar_url,
      role: row.host_role,
      combat_level: row.host_combat_level,
    }),
  };
}

async function getRoom(roomId, viewerId) {
  const row = await roomRow(roomId);
  if (!row) return null;
  const members = await roomMembers(roomId);
  const teams = { a: [], b: [] };
  for (const member of members) teams[member.team].push(member);
  const isMember = members.some((member) => member.id === Number(viewerId));
  const readyCount = members.filter((member) => member.ready).length;
  const pending = isMember ? await pendingInvites(roomId) : [];
  const spectators = await spectatorCount(roomId);
  const roundRows = await q(
    `SELECT round_no, winner, score_a, score_b, created_at
       FROM challenge_rounds WHERE room_id = ? ORDER BY round_no`,
    [roomId]
  );
  const rounds = roundRows.map((item) => ({
    roundNo: Number(item.round_no),
    winner: item.winner,
    scoreA: Number(item.score_a || 0),
    scoreB: Number(item.score_b || 0),
    endedAt: item.created_at,
  }));

  return {
    ...roomBase(row),
    members,
    series: {
      winsA: rounds.filter((item) => item.winner === 'a').length,
      winsB: rounds.filter((item) => item.winner === 'b').length,
      rounds,
    },
    teams,
    playerCount: members.length,
    readyCount,
    allReady: members.length > 0 && readyCount === members.length,
    full: members.length >= Number(row.max_players),
    spectatorCount: spectators,
    spectatorLimit: SPECTATOR_LIMIT,
    isHost: Number(row.host_id) === Number(viewerId),
    isMember,
    pendingInvites: pending,
  };
}

async function expireStaleRooms() {
  try {
    await q(
      `UPDATE challenge_rooms
          SET status = 'closed', closed_at = NOW()
        WHERE status = 'live'
          AND started_at IS NOT NULL
          AND started_at < DATE_SUB(NOW(), INTERVAL time_limit_sec + ? SECOND)`,
      [CHALLENGE_TIME_GRACE_SEC]
    );

    // 空房：等待超过 10 分钟仍没坐满，自动解散
    await q(
      `UPDATE challenge_rooms r
          SET r.status = 'closed', r.closed_at = NOW()
        WHERE r.status = 'waiting'
          AND (SELECT COUNT(*) FROM challenge_room_players p WHERE p.room_id = r.id) < r.max_players
          AND r.created_at < DATE_SUB(NOW(), INTERVAL ? SECOND)`,
      [EMPTY_ROOM_TIMEOUT_SEC]
    );

    // 准备超时：坐满后 2 分钟仍未全部准备，自动关闭
    await q(
      `UPDATE challenge_rooms r
          SET r.status = 'closed', r.closed_at = NOW()
        WHERE r.status = 'waiting'
          AND (SELECT COUNT(*) FROM challenge_room_players p WHERE p.room_id = r.id) = r.max_players
          AND (SELECT COUNT(*) FROM challenge_room_players p WHERE p.room_id = r.id AND p.ready = 1) < r.max_players
          AND GREATEST(
                r.updated_at,
                COALESCE((SELECT MAX(p.joined_at) FROM challenge_room_players p WHERE p.room_id = r.id), r.created_at)
              ) < DATE_SUB(NOW(), INTERVAL ? SECOND)`,
      [READY_TIMEOUT_SEC]
    );
  } catch {
    /* 非关键路径，失败不阻塞主流程 */
  }
}

async function spectatorCount(roomId) {
  const row = await one('SELECT COUNT(*) AS n FROM challenge_spectators WHERE room_id = ?', [roomId]);
  return Number(row?.n || 0);
}

async function joinSpectate(userId, roomId) {
  const row = await roomRow(roomId);
  if (!row) throw notFound('房间不存在');
  if (row.status !== 'live') throw conflict('只有比赛进行中的房间可以观战');

  await withTransaction(async (conn) => {
    const [rows] = await conn.query(
      'SELECT COUNT(*) AS n FROM challenge_spectators WHERE room_id = ? FOR UPDATE',
      [roomId]
    );
    if (Number(rows[0].n) >= SPECTATOR_LIMIT) throw conflict(`观战位已满（最多 ${SPECTATOR_LIMIT} 人）`);
    await conn.query(
      `INSERT INTO challenge_spectators (room_id, user_id)
       VALUES (?, ?)
       ON DUPLICATE KEY UPDATE joined_at = joined_at`,
      [roomId, userId]
    );
  });

  return { spectators: await spectatorCount(roomId), limit: SPECTATOR_LIMIT };
}

async function leaveSpectate(userId, roomId) {
  await q('DELETE FROM challenge_spectators WHERE room_id = ? AND user_id = ?', [roomId, userId]);
  return { spectators: await spectatorCount(roomId), limit: SPECTATOR_LIMIT };
}

const QUEUE_KINDS = ['ranked', 'challenge'];

async function joinQueue(userId, serverKey, kind = 'challenge') {
  const key = String(serverKey || '').trim();
  if (!key) throw badRequest('缺少服务器标识');
  const type = QUEUE_KINDS.includes(kind) ? kind : 'challenge';
  await q(
    `INSERT INTO challenge_queue (server_key, user_id, kind)
     VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE kind = VALUES(kind)`,
    [key, userId, type]
  );
  return queueList(key, userId);
}

async function leaveQueue(userId, serverKey) {
  const key = String(serverKey || '').trim();
  if (!key) throw badRequest('缺少服务器标识');
  await q('DELETE FROM challenge_queue WHERE server_key = ? AND user_id = ?', [key, userId]);
  return queueList(key, userId);
}

async function queueList(serverKey, viewerId) {
  const key = String(serverKey || '').trim();
  if (!key) throw badRequest('缺少服务器标识');
  const rows = await q(
    `SELECT cq.user_id, cq.kind, cq.created_at,
            u.username, u.game_name, u.avatar, u.avatar_url, u.role, u.combat_level,
            EXISTS(SELECT 1 FROM ranked_queue rq WHERE rq.user_id = u.id) AS ranked_waiting
       FROM challenge_queue cq
       JOIN users u ON u.id = cq.user_id
      WHERE cq.server_key = ?
      ORDER BY ranked_waiting DESC, cq.created_at ASC
      LIMIT 50`,
    [key]
  );
  const entries = rows.map((row, index) => ({
    position: index + 1,
    user: publicUser({ ...row, id: row.user_id }),
    kind: row.kind,
    priority: Number(row.ranked_waiting) ? 'ranked' : 'challenge',
    joinedAt: row.created_at,
    mine: Number(row.user_id) === Number(viewerId),
  }));
  return { serverKey: key, entries, count: entries.length };
}

async function listRooms() {
  await expireStaleRooms();
  const rows = await q(
    `SELECT r.*, u.username AS host_username, u.game_name AS host_game_name,
            u.avatar AS host_avatar, u.avatar_url AS host_avatar_url,
            u.role AS host_role, u.combat_level AS host_combat_level,
            s.name AS server_name, s.ip AS server_ip, s.port AS server_port,
            c.victory_type, c.victory_limit,
            (SELECT COUNT(*) FROM challenge_room_players p WHERE p.room_id = r.id) AS player_count,
            (SELECT COUNT(*) FROM challenge_room_players p WHERE p.room_id = r.id AND p.ready = 1) AS ready_count
       FROM challenge_rooms r
       JOIN users u ON u.id = r.host_id
       LEFT JOIN servers s ON s.server_key = r.server_key
       LEFT JOIN challenge_configs c ON c.room_id = r.id
      WHERE r.status = 'waiting'
        AND r.updated_at > (NOW() - INTERVAL ? HOUR)
      ORDER BY r.created_at DESC
      LIMIT 30`,
    [STALE_HOURS]
  );
  return rows.map((row) => ({
    ...roomBase(row),
    playerCount: Number(row.player_count || 0),
    readyCount: Number(row.ready_count || 0),
    full: Number(row.player_count || 0) >= Number(row.max_players),
  }));
}

async function listLiveRooms() {
  await expireStaleRooms();
  const rows = await q(
    `SELECT r.*, u.username AS host_username, u.game_name AS host_game_name,
            u.avatar AS host_avatar, u.avatar_url AS host_avatar_url,
            u.role AS host_role, u.combat_level AS host_combat_level,
            s.name AS server_name, s.ip AS server_ip, s.port AS server_port,
            c.victory_type, c.victory_limit,
            (SELECT COUNT(*) FROM challenge_room_players p WHERE p.room_id = r.id) AS player_count,
            (SELECT COUNT(*) FROM challenge_room_players p WHERE p.room_id = r.id AND p.ready = 1) AS ready_count,
            (SELECT COUNT(*) FROM challenge_spectators sp WHERE sp.room_id = r.id) AS spectator_count
       FROM challenge_rooms r
       JOIN users u ON u.id = r.host_id
       LEFT JOIN servers s ON s.server_key = r.server_key
       LEFT JOIN challenge_configs c ON c.room_id = r.id
      WHERE r.status = 'live'
        AND r.updated_at > (NOW() - INTERVAL ? HOUR)
      ORDER BY r.started_at DESC, r.id DESC
      LIMIT 6`,
    [STALE_HOURS]
  );
  return rows.map((row) => {
    const spectators = Number(row.spectator_count || 0);
    return {
      ...roomBase(row),
      playerCount: Number(row.player_count || 0),
      readyCount: Number(row.ready_count || 0),
      full: true,
      spectatorCount: spectators,
      spectatorLimit: SPECTATOR_LIMIT,
      spectatorFull: spectators >= SPECTATOR_LIMIT,
    };
  });
}

/** 最近约战战绩：只统计已经结算、且当前用户确实入座的房间。 */
async function historyOf(userId, limit = 20) {
  const capped = Math.min(50, Math.max(1, Number(limit) || 20));
  const rows = await q(
    `SELECT res.room_id, res.winner, res.score_a, res.score_b, res.ended_at,
            r.day_seq, r.title, r.mode, r.map, r.best_of, r.server_key,
            s.name AS server_name,
            st.team AS my_team,
            (SELECT GROUP_CONCAT(u2.game_name ORDER BY u2.id SEPARATOR '、')
               FROM challenge_player_stats p2
               JOIN users u2 ON u2.id = p2.user_id
              WHERE p2.room_id = res.room_id AND p2.team <> st.team) AS opponents
       FROM challenge_results res
       JOIN challenge_rooms r ON r.id = res.room_id
       JOIN challenge_player_stats st ON st.room_id = res.room_id AND st.user_id = ?
       LEFT JOIN servers s ON s.server_key = r.server_key
      ORDER BY res.ended_at DESC, res.room_id DESC
      LIMIT ?`,
    [userId, capped]
  );
  return {
    items: rows.map((row) => ({
      roomId: Number(row.room_id),
      displayNo: row.day_seq ? Number(row.day_seq) : Number(row.room_id),
      title: row.title,
      mode: row.mode,
      map: row.map || null,
      bestOf: Number(row.best_of || 3) === 1 ? 1 : 3,
      serverName: row.server_name || row.server_key || null,
      myTeam: row.my_team,
      won: row.winner === row.my_team,
      scoreA: Number(row.score_a || 0),
      scoreB: Number(row.score_b || 0),
      opponents: row.opponents || '',
      endedAt: row.ended_at,
    })),
    limit: capped,
  };
}

async function activeRoomOf(userId) {
  return one(
    `SELECT r.id
       FROM challenge_room_players p
       JOIN challenge_rooms r ON r.id = p.room_id
      WHERE p.user_id = ? AND r.status IN ('waiting', 'live')
      ORDER BY r.id DESC
      LIMIT 1`,
    [userId]
  );
}

async function invitesOf(userId) {
  const rows = await q(
    `SELECT i.id, i.created_at,
            r.id AS room_id, r.title, r.mode, r.map, r.status, r.max_players,
            u.id AS from_id, u.username AS from_username, u.game_name AS from_game_name,
            u.avatar AS from_avatar, u.avatar_url AS from_avatar_url, u.role AS from_role,
            (SELECT COUNT(*) FROM challenge_room_players p WHERE p.room_id = r.id) AS player_count
       FROM challenge_invites i
       JOIN challenge_rooms r ON r.id = i.room_id
       JOIN users u ON u.id = i.from_user_id
      WHERE i.to_user_id = ? AND i.status = 'pending'
        AND r.status = 'waiting'
        AND r.updated_at > (NOW() - INTERVAL ? HOUR)
      ORDER BY i.id DESC
      LIMIT 10`,
    [userId, STALE_HOURS]
  );
  return rows.map((row) => ({
    id: Number(row.id),
    createdAt: row.created_at,
    from: publicUser({
      id: row.from_id,
      username: row.from_username,
      game_name: row.from_game_name,
      avatar: row.from_avatar,
      avatar_url: row.from_avatar_url,
      role: row.from_role,
      combat_level: 0,
    }),
    room: {
      id: Number(row.room_id),
      title: row.title,
      mode: row.mode,
      map: row.map || null,
      status: row.status,
      maxPlayers: Number(row.max_players),
      playerCount: Number(row.player_count || 0),
    },
  }));
}

async function getState(userId) {
  const active = await activeRoomOf(userId);
  const [myRoom, rooms, liveRooms, invites, lastResult] = await Promise.all([
    active ? getRoom(active.id, userId) : Promise.resolve(null),
    listRooms(),
    listLiveRooms(),
    invitesOf(userId),
    latestResultOf(userId),
  ]);
  return { myRoom, rooms, liveRooms, invites, lastResult };
}

/** 锁服查询：一台服务器同时只能有一个约战 live。 */
async function activeChallengesByServer() {
  const rows = await q(
    `SELECT r.id, r.server_key, r.mode, r.title, r.host_id, r.best_of,
            c.victory_type, c.victory_limit,
            (SELECT COUNT(*) FROM challenge_room_players p WHERE p.room_id = r.id) AS players
       FROM challenge_rooms r
       LEFT JOIN challenge_configs c ON c.room_id = r.id
      WHERE r.status = 'live' AND r.server_key IS NOT NULL`
  );
  const map = new Map();
  for (const row of rows) {
    map.set(row.server_key, {
      id: Number(row.id),
      roomId: Number(row.id),
      serverKey: row.server_key,
      mode: row.mode,
      title: row.title,
      hostId: Number(row.host_id),
      players: Number(row.players || 0),
      victoryType: row.victory_type || 'kills',
      victoryLimit: Number(row.victory_limit || 10),
      bestOf: Number(row.best_of || 3) === 1 ? 1 : 3,
    });
  }
  return map;
}

async function challengeAccess(userId, serverKey) {
  const row = await one(
    `SELECT r.id, r.mode, r.title, r.status
       FROM challenge_rooms r
      WHERE r.server_key = ? AND r.status = 'live'
      ORDER BY r.id DESC LIMIT 1`,
    [serverKey]
  );
  if (!row) return { active: false, participant: false, room: null };
  const member = await one(
    'SELECT team FROM challenge_room_players WHERE room_id = ? AND user_id = ? LIMIT 1',
    [row.id, userId]
  );
  return {
    active: true,
    participant: Boolean(member),
    team: member ? member.team : null,
    room: { id: Number(row.id), mode: row.mode, title: row.title },
  };
}

async function resultOf(roomId) {
  const row = await one(
    `SELECT r.id, r.host_id, r.title, r.mode, r.server_key, r.status, r.map, r.started_at, r.day_seq, r.best_of,
            res.winner, res.score_a, res.score_b, res.victory_type,
            res.victory_limit, res.ended_at,
            s.name AS server_name
       FROM challenge_rooms r
       LEFT JOIN challenge_results res ON res.room_id = r.id
       LEFT JOIN servers s ON s.server_key = r.server_key
      WHERE r.id = ? LIMIT 1`,
    [roomId]
  );
  if (!row) return null;
  const members = await roomMembers(roomId);
  const roundRows = await q(
    `SELECT round_no, winner, score_a, score_b, created_at
       FROM challenge_rounds WHERE room_id = ? ORDER BY round_no`,
    [roomId]
  );
  const rounds = roundRows.map((item) => ({
    roundNo: Number(item.round_no),
    winner: item.winner,
    scoreA: Number(item.score_a || 0),
    scoreB: Number(item.score_b || 0),
    endedAt: item.created_at,
  }));
  return {
    roomId: Number(row.id),
    displayNo: row.day_seq ? Number(row.day_seq) : Number(row.id),
    title: row.title,
    mode: row.mode,
    map: row.map || null,
    status: row.status,
    bestOf: Number(row.best_of || 3) === 1 ? 1 : 3,
    serverKey: row.server_key || null,
    serverName: row.server_name || null,
    hostId: Number(row.host_id),
    winner: row.winner || null,
    scoreA: Number(row.score_a || 0),
    scoreB: Number(row.score_b || 0),
    victoryType: row.victory_type || 'kills',
    victoryLimit: Number(row.victory_limit || 10),
    victoryLabel: victoryLabel(row.victory_type || 'kills', Number(row.victory_limit || 10)),
    rounds,
    series: {
      winsA: rounds.filter((item) => item.winner === 'a').length,
      winsB: rounds.filter((item) => item.winner === 'b').length,
      rounds,
    },
    startedAt: row.started_at || null,
    endedAt: row.ended_at || null,
    players: members,
  };
}

async function latestResultOf(userId) {
  const row = await one(
    `SELECT r.id
       FROM challenge_rooms r
       JOIN challenge_results res ON res.room_id = r.id
      WHERE res.ended_at > (NOW() - INTERVAL 2 HOUR)
        AND (
          EXISTS (SELECT 1 FROM challenge_room_players p WHERE p.room_id = r.id AND p.user_id = ?)
          OR EXISTS (SELECT 1 FROM challenge_spectators s WHERE s.room_id = r.id AND s.user_id = ?)
        )
      ORDER BY res.ended_at DESC LIMIT 1`,
    [userId, userId]
  );
  return row ? resultOf(row.id) : null;
}

async function withTransaction(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

async function createRoom(user, fields = {}) {
  const mode = normalizeMode(fields.mode);
  const maxPlayers = MODE_SLOTS[mode] * 2;
  const title = normalizeTitle(fields.title, `${user.game_name || user.username} 的约战`);
  const map = normalizeMap(fields.map);
  const serverKey = String(fields.serverKey || '').trim();
  const victoryType = normalizeVictoryType(fields.victoryType);
  const victoryLimit = normalizeVictoryLimit(fields.victoryLimit);
  const bestOf = normalizeBestOf(fields.bestOf);
  const isPrivate = Boolean(fields.private);
  // 仅连续房间（rematch）内部复用旧房哈希；外部建房不会传这个字段。
  const passwordHash = isPrivate
    ? (fields.passwordHash || bcrypt.hashSync(normalizeRoomPassword(fields.password), 8))
    : null;

  if (!serverKey) throw badRequest('请选择一台服务器后再开房');

  if (serverKey) {
    const server = await one(
      `SELECT s.server_key, s.is_challenge, COALESCE(st.online, 0) AS online
         FROM servers s
         LEFT JOIN server_status st ON st.server_id = s.id
        WHERE s.server_key = ? AND s.enabled = 1
        LIMIT 1`,
      [serverKey]
    );
    if (!server) throw badRequest('指定的服务器不存在或已停用');
    if (!Number(server.is_challenge)) throw badRequest('这台服务器不是约战服，不能开约战');
    if (!Number(server.online)) throw badRequest('这台约战服当前离线，等它上线后再开房');
  }

  await expireStaleRooms();
  const roomId = await withTransaction(async (conn) => {
    const [active] = await conn.query(
      `SELECT r.id FROM challenge_room_players p
         JOIN challenge_rooms r ON r.id = p.room_id
        WHERE p.user_id = ? AND r.status IN ('waiting', 'live')
        LIMIT 1 FOR UPDATE`,
      [user.id]
    );
    if (active.length > 0) throw conflict('你已经在约战房间中，先退出当前房间');

    // 房号按自然日重置：锁住当天最后一条，取 next = max + 1
    // 并发下靠 (day_date, day_seq) 唯一键兜底，撞号后重试取号
    let result = null;
    for (let attempt = 0; attempt < 3 && !result; attempt += 1) {
      const [seqRows] = await conn.query(
        `SELECT day_seq FROM challenge_rooms
          WHERE day_date = CURDATE() AND day_seq IS NOT NULL
          ORDER BY day_seq DESC LIMIT 1 FOR UPDATE`
      );
      const daySeq = seqRows.length > 0 ? Number(seqRows[0].day_seq) + 1 : 1;
      try {
        const [inserted] = await conn.query(
          `INSERT INTO challenge_rooms (host_id, day_date, day_seq, title, mode, map, server_key, max_players, best_of, time_limit_sec, is_private, password_hash)
           VALUES (?, CURDATE(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            user.id,
            daySeq,
            title,
            mode,
            map,
            serverKey,
            maxPlayers,
            bestOf,
            CHALLENGE_TIME_LIMIT_SEC,
            isPrivate ? 1 : 0,
            passwordHash,
          ]
        );
        result = inserted;
      } catch (err) {
        if (err.code !== 'ER_DUP_ENTRY' || attempt === 2) throw err;
      }
    }
    await conn.query(
      `INSERT INTO challenge_room_players (room_id, user_id, team, ready)
       VALUES (?, ?, 'a', 1)`,
      [result.insertId, user.id]
    );
    await conn.query(
      `INSERT INTO challenge_configs (room_id, victory_type, victory_limit)
       VALUES (?, ?, ?)`,
      [result.insertId, victoryType, victoryLimit]
    );
    return result.insertId;
  });

  return getRoom(roomId, user.id);
}

async function joinRoom(userId, roomId, password = '') {
  await withTransaction(async (conn) => {
    const [rooms] = await conn.query(
      'SELECT id, status, max_players, is_private, password_hash FROM challenge_rooms WHERE id = ? LIMIT 1 FOR UPDATE',
      [roomId]
    );
    const room = rooms[0];
    if (!room) throw notFound('房间不存在');
    if (room.status !== 'waiting') throw conflict('房间已开赛或已关闭');

    const [members] = await conn.query(
      'SELECT user_id, team FROM challenge_room_players WHERE room_id = ? FOR UPDATE',
      [roomId]
    );
    if (members.some((member) => Number(member.user_id) === Number(userId))) {
      return;
    }

    if (Number(room.is_private)) {
      const supplied = String(password || '');
      if (!supplied) throw badRequest('这是私密房，请输入房间密码');
      if (!room.password_hash || !bcrypt.compareSync(supplied, room.password_hash)) {
        throw forbidden('房间密码不正确');
      }
    }

    const active = await conn.query(
      `SELECT r.id FROM challenge_room_players p
         JOIN challenge_rooms r ON r.id = p.room_id
        WHERE p.user_id = ? AND r.status IN ('waiting', 'live') AND r.id <> ?
        LIMIT 1 FOR UPDATE`,
      [userId, roomId]
    );
    if (active[0].length > 0) throw conflict('你已经在另一个约战房间中');

    if (members.length >= Number(room.max_players)) throw conflict('房间已经满了');

    const slots = Number(room.max_players) / 2;
    const countA = members.filter((member) => member.team === 'a').length;
    const countB = members.filter((member) => member.team === 'b').length;
    let team = 'a';
    if (countA >= slots || (countA > countB && countB < slots)) team = 'b';

    await conn.query(
      `INSERT INTO challenge_room_players (room_id, user_id, team, ready)
       VALUES (?, ?, ?, 0)`,
      [roomId, userId, team]
    );
    await conn.query(
      `UPDATE challenge_invites
          SET status = 'accepted', responded_at = NOW()
        WHERE room_id = ? AND to_user_id = ? AND status = 'pending'`,
      [roomId, userId]
    );
  });

  return getRoom(roomId, userId);
}

async function leaveRoom(userId, roomId) {
  const result = await withTransaction(async (conn) => {
    const [rooms] = await conn.query(
      'SELECT id, host_id, status FROM challenge_rooms WHERE id = ? LIMIT 1 FOR UPDATE',
      [roomId]
    );
    const room = rooms[0];
    if (!room) throw notFound('房间不存在');

    const [members] = await conn.query(
      'SELECT user_id FROM challenge_room_players WHERE room_id = ? ORDER BY joined_at ASC, user_id ASC FOR UPDATE',
      [roomId]
    );
    if (!members.some((member) => Number(member.user_id) === Number(userId))) {
      throw badRequest('你不在这个房间里');
    }

    if (room.status === 'closed') {
      await conn.query('DELETE FROM challenge_room_players WHERE room_id = ? AND user_id = ?', [roomId, userId]);
      return { closed: true };
    }

    const others = members.filter((member) => Number(member.user_id) !== Number(userId));
    const isHost = Number(room.host_id) === Number(userId);

    // 房主离开时优先把房间交给最早加入的成员；只有房主独处才关房。
    if (isHost && others.length > 0) {
      const nextHost = Number(others[0].user_id);
      await conn.query('UPDATE challenge_rooms SET host_id = ?, updated_at = NOW() WHERE id = ?', [
        nextHost,
        roomId,
      ]);
      if (room.status === 'waiting') {
        await conn.query('UPDATE challenge_room_players SET ready = 1 WHERE room_id = ? AND user_id = ?', [
          roomId,
          nextHost,
        ]);
      }
      await conn.query('DELETE FROM challenge_room_players WHERE room_id = ? AND user_id = ?', [roomId, userId]);
      await conn.query(
        "UPDATE challenge_invites SET status = 'cancelled', responded_at = NOW() WHERE room_id = ? AND from_user_id = ? AND status = 'pending'",
        [roomId, userId]
      );
      return { closed: false, transferredTo: nextHost };
    }

    if (isHost) {
      await conn.query("UPDATE challenge_rooms SET status = 'closed', closed_at = NOW() WHERE id = ?", [roomId]);
      await conn.query(
        "UPDATE challenge_invites SET status = 'cancelled', responded_at = NOW() WHERE room_id = ? AND status = 'pending'",
        [roomId]
      );
      await conn.query('DELETE FROM challenge_room_players WHERE room_id = ? AND user_id = ?', [roomId, userId]);
      return { closed: true };
    }

    await conn.query('DELETE FROM challenge_room_players WHERE room_id = ? AND user_id = ?', [roomId, userId]);
    return { closed: false };
  });

  return result;
}

/** 等待中的房主可以把房间交给另一名成员，避免房主临时离开就散房。 */
async function transferHost(user, roomId, targetId) {
  const target = Number(targetId);
  if (!Number.isSafeInteger(target) || target <= 0) throw badRequest('请选择要转让的玩家');

  await withTransaction(async (conn) => {
    const [rooms] = await conn.query(
      'SELECT id, host_id, status FROM challenge_rooms WHERE id = ? LIMIT 1 FOR UPDATE',
      [roomId]
    );
    const room = rooms[0];
    if (!room) throw notFound('房间不存在');
    if (Number(room.host_id) !== Number(user.id)) throw forbidden('只有房主可以转让房间');
    if (room.status !== 'waiting') throw conflict('开赛后不能转让房主');
    if (target === Number(user.id)) throw badRequest('你已经是房主了');

    const [members] = await conn.query(
      'SELECT user_id FROM challenge_room_players WHERE room_id = ? FOR UPDATE',
      [roomId]
    );
    if (!members.some((member) => Number(member.user_id) === target)) {
      throw badRequest('只能把房间转让给当前房间里的玩家');
    }

    await conn.query('UPDATE challenge_rooms SET host_id = ?, updated_at = NOW() WHERE id = ?', [target, roomId]);
    await conn.query('UPDATE challenge_room_players SET ready = 1 WHERE room_id = ? AND user_id = ?', [
      roomId,
      target,
    ]);
  });

  return { transferredTo: target, room: await getRoom(roomId, user.id) };
}

async function closeRoom(user, roomId) {
  const row = await roomRow(roomId);
  if (!row) throw notFound('房间不存在');
  if (Number(row.host_id) !== Number(user.id)) throw forbidden('只有房主可以关闭房间');

  await withTransaction(async (conn) => {
    await conn.query(
      "UPDATE challenge_rooms SET status = 'closed', closed_at = NOW() WHERE id = ? AND status IN ('waiting','live')",
      [roomId]
    );
    await conn.query(
      "UPDATE challenge_invites SET status = 'cancelled', responded_at = NOW() WHERE room_id = ? AND status = 'pending'",
      [roomId]
    );
  });

  return { closed: true };
}

async function invite(user, roomId, targetId) {
  if (Number(targetId) === Number(user.id)) throw badRequest('不能邀请自己');

  await withTransaction(async (conn) => {
    const [rooms] = await conn.query(
      'SELECT id, status, max_players FROM challenge_rooms WHERE id = ? LIMIT 1 FOR UPDATE',
      [roomId]
    );
    const room = rooms[0];
    if (!room) throw notFound('房间不存在');
    if (room.status !== 'waiting') throw conflict('房间已开赛或已关闭');

    const [members] = await conn.query(
      'SELECT user_id FROM challenge_room_players WHERE room_id = ?',
      [roomId]
    );
    if (!members.some((member) => Number(member.user_id) === Number(user.id))) {
      throw forbidden('只有房间成员可以邀请玩家');
    }
    if (members.length >= Number(room.max_players)) throw conflict('房间已经满了');
    if (members.some((member) => Number(member.user_id) === Number(targetId))) {
      throw conflict('对方已经在房间里');
    }

    const [targets] = await conn.query(
      "SELECT id FROM users WHERE id = ? AND status = 'active' LIMIT 1",
      [targetId]
    );
    if (!targets[0]) throw notFound('被邀请的玩家不存在');

    await conn.query(
      `INSERT INTO challenge_invites (room_id, from_user_id, to_user_id, status)
       VALUES (?, ?, ?, 'pending')
       ON DUPLICATE KEY UPDATE
         from_user_id = VALUES(from_user_id),
         status = 'pending',
         created_at = NOW(),
         responded_at = NULL`,
      [roomId, user.id, targetId]
    );
  });

  return { invited: true };
}

async function respond(userId, inviteId, action) {
  const accept = action === 'accept';
  if (!accept && action !== 'decline') throw badRequest('邀请操作只能是 accept / decline');

  const result = await withTransaction(async (conn) => {
    const [invites] = await conn.query(
      `SELECT i.*, r.status AS room_status, r.max_players, r.host_id
         FROM challenge_invites i
         JOIN challenge_rooms r ON r.id = i.room_id
        WHERE i.id = ? LIMIT 1 FOR UPDATE`,
      [inviteId]
    );
    const row = invites[0];
    if (!row) throw notFound('邀请不存在');
    if (Number(row.to_user_id) !== Number(userId)) throw forbidden('这条邀请不是给你的');
    if (row.status !== 'pending') throw conflict('邀请已经处理过了');
    if (row.room_status !== 'waiting') throw conflict('房间已开赛或已关闭');

    if (!accept) {
      await conn.query(
        "UPDATE challenge_invites SET status = 'declined', responded_at = NOW() WHERE id = ?",
        [inviteId]
      );
      return { accepted: false, roomId: Number(row.room_id) };
    }

    const [members] = await conn.query(
      'SELECT user_id FROM challenge_room_players WHERE room_id = ? FOR UPDATE',
      [row.room_id]
    );
    if (members.some((member) => Number(member.user_id) === Number(userId))) {
      await conn.query(
        "UPDATE challenge_invites SET status = 'accepted', responded_at = NOW() WHERE id = ?",
        [inviteId]
      );
      return { accepted: true, roomId: Number(row.room_id) };
    }

    const active = await conn.query(
      `SELECT r.id FROM challenge_room_players p
         JOIN challenge_rooms r ON r.id = p.room_id
        WHERE p.user_id = ? AND r.status IN ('waiting', 'live') AND r.id <> ?
        LIMIT 1 FOR UPDATE`,
      [userId, row.room_id]
    );
    if (active[0].length > 0) throw conflict('你已经在一个约战房间里了');
    if (members.length >= Number(row.max_players)) throw conflict('房间已经满了');

    const slots = Number(row.max_players) / 2;
    const [teamRows] = await conn.query(
      'SELECT team, COUNT(*) AS count FROM challenge_room_players WHERE room_id = ? GROUP BY team',
      [row.room_id]
    );
    const countA = Number((teamRows.find((item) => item.team === 'a') || {}).count || 0);
    const countB = Number((teamRows.find((item) => item.team === 'b') || {}).count || 0);
    let team = 'a';
    if (countA >= slots || (countA > countB && countB < slots)) team = 'b';

    await conn.query(
      `INSERT INTO challenge_room_players (room_id, user_id, team, ready)
       VALUES (?, ?, ?, 0)`,
      [row.room_id, userId, team]
    );
    await conn.query(
      "UPDATE challenge_invites SET status = 'accepted', responded_at = NOW() WHERE id = ?",
      [inviteId]
    );
    return { accepted: true, roomId: Number(row.room_id) };
  });

  return { ...result, room: await getRoom(result.roomId, userId) };
}

async function setReady(userId, roomId, ready) {
  const member = await one(
    'SELECT room_id FROM challenge_room_players WHERE room_id = ? AND user_id = ? LIMIT 1',
    [roomId, userId]
  );
  if (!member) throw forbidden('你不在这个房间里');

  const room = await roomRow(roomId);
  if (!room) throw notFound('房间不存在');
  if (room.status !== 'waiting') throw conflict('房间已开赛或已关闭');

  await q('UPDATE challenge_room_players SET ready = ? WHERE room_id = ? AND user_id = ?', [
    ready ? 1 : 0,
    roomId,
    userId,
  ]);
  await q('UPDATE challenge_rooms SET updated_at = NOW() WHERE id = ?', [roomId]);
  return getRoom(roomId, userId);
}

async function switchTeam(userId, roomId, team) {
  const target = team === 'b' ? 'b' : 'a';
  await withTransaction(async (conn) => {
    const [rooms] = await conn.query(
      'SELECT id, status, max_players FROM challenge_rooms WHERE id = ? LIMIT 1 FOR UPDATE',
      [roomId]
    );
    const room = rooms[0];
    if (!room) throw notFound('房间不存在');
    if (room.status !== 'waiting') throw conflict('开赛后不能换队');
    if (Number(room.max_players) < 4) throw badRequest('1v1 房间不需要换队');

    const [members] = await conn.query(
      'SELECT user_id, team FROM challenge_room_players WHERE room_id = ? FOR UPDATE',
      [roomId]
    );
    const me = members.find((member) => Number(member.user_id) === Number(userId));
    if (!me) throw forbidden('你不在这个房间里');
    if (me.team === target) return;

    const slots = Math.floor(Number(room.max_players) / 2);
    const count = members.filter((member) => member.team === target).length;
    if (count >= slots) throw conflict('目标队伍已经满了');

    await conn.query('UPDATE challenge_room_players SET team = ?, ready = 0 WHERE room_id = ? AND user_id = ?', [
      target,
      roomId,
      userId,
    ]);
    await conn.query('UPDATE challenge_rooms SET updated_at = NOW() WHERE id = ?', [roomId]);
  });

  return getRoom(roomId, userId);
}

async function startRoom(user, roomId) {
  await withTransaction(async (conn) => {
    const [rooms] = await conn.query(
      'SELECT id, host_id, status, max_players, server_key FROM challenge_rooms WHERE id = ? LIMIT 1 FOR UPDATE',
      [roomId]
    );
    const room = rooms[0];
    if (!room) throw notFound('房间不存在');
    if (Number(room.host_id) !== Number(user.id)) throw forbidden('只有房主可以开始约战');
    if (room.status !== 'waiting') throw conflict('房间状态不允许开赛');
    if (!room.server_key) throw badRequest('请先选择服务器');
    const [configs] = await conn.query(
      'SELECT victory_type, victory_limit FROM challenge_configs WHERE room_id = ? LIMIT 1',
      [roomId]
    );
    if (!configs[0]) throw badRequest('房间缺少胜利条件，请重新开房');

    const [serverRows] = await conn.query(
      `SELECT s.server_key, s.is_challenge, COALESCE(st.online, 0) AS online
         FROM servers s
         LEFT JOIN server_status st ON st.server_id = s.id
        WHERE s.server_key = ? AND s.enabled = 1
        LIMIT 1`,
      [room.server_key]
    );
    const server = serverRows[0];
    if (!server) throw badRequest('约战服务器不存在或已停用，换一台再开');
    if (!Number(server.is_challenge)) throw badRequest('这台服务器不是约战服，换一台再开');
    if (!Number(server.online)) throw conflict('这台约战服已离线，暂时不能开赛');

    const [members] = await conn.query(
      'SELECT user_id, ready FROM challenge_room_players WHERE room_id = ?',
      [roomId]
    );
    if (members.length < Number(room.max_players)) throw badRequest('人还没齐，再等等');
    if (members.some((member) => !member.ready)) throw badRequest('还有玩家没有准备');

    const [busy] = await conn.query(
      `SELECT id FROM challenge_rooms
        WHERE server_key = ? AND status = 'live' AND id <> ?
        LIMIT 1 FOR UPDATE`,
      [room.server_key, roomId]
    );
    if (busy.length > 0) throw conflict('该服务器已有约战正在进行');

    const [rankedBusy] = await conn.query(
      `SELECT id FROM ranked_matches
        WHERE server_key = ? AND status IN ('waiting','live')
        LIMIT 1 FOR UPDATE`,
      [room.server_key]
    );
    if (rankedBusy.length > 0) throw conflict('该服务器正在打排位，换一台再开');

    await conn.query("UPDATE challenge_rooms SET status = 'live', started_at = NOW() WHERE id = ?", [
      roomId,
    ]);
    await conn.query(
      "UPDATE challenge_invites SET status = 'cancelled', responded_at = NOW() WHERE room_id = ? AND status = 'pending'",
      [roomId]
    );
  });

  return getRoom(roomId, user.id);
}


const MAX_ROUNDS = 3;

async function finishRound(roomId, { winner, scoreA, scoreB, userId } = {}) {
  const room = await one('SELECT * FROM challenge_rooms WHERE id = ?', [roomId]);
  if (!room) throw notFound('房间不存在');
  if (room.status !== 'live') throw conflict('房间不在比赛中');
  const member = await one('SELECT user_id FROM challenge_room_players WHERE room_id = ? AND user_id = ?', [roomId, userId]);
  if (!member) throw forbidden('只有参赛玩家可以提交本局结果');
  const roundNo = Number(room.round_no || 1);
  const w = winner === 'b' ? 'b' : 'a';
  await q(
    `INSERT INTO challenge_rounds (room_id, round_no, winner, score_a, score_b)
     VALUES (?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE winner = VALUES(winner), score_a = VALUES(score_a), score_b = VALUES(score_b)`,
    [roomId, roundNo, w, Number(scoreA) || 0, Number(scoreB) || 0]
  );
  await q('UPDATE challenge_rooms SET started_at = NULL, updated_at = NOW() WHERE id = ?', [roomId]);
  const maxRounds = Number(room.best_of || MAX_ROUNDS) === 1 ? 1 : MAX_ROUNDS;
  return { roundNo, maxRounds, winner: w };
}

async function rematch(roomId, user) {
  const callerId = Number(user && typeof user === 'object' ? user.id : user);
  const old = await roomRow(roomId);
  if (!old) throw notFound('房间不存在');
  if (Number(old.host_id) !== callerId) throw forbidden('只有房主可以再来一局');
  if (old.status !== 'closed') throw conflict('本局还没结束，结束后才能再来一局');
  const settled = await one('SELECT room_id FROM challenge_results WHERE room_id = ? LIMIT 1', [roomId]);
  if (!settled) throw conflict('本局还没有结算，暂时不能再来一局');

  const members = await roomMembers(roomId);
  const hostMember = members.find((item) => item.id === callerId);
  const baseTitle = String(old.title || '约战').replace(/\s*·\s*再来一局\s*$/, '').slice(0, 40);
  const actor = (user && typeof user === 'object')
    ? user
    : { id: callerId, username: old.host_username, game_name: old.host_game_name };

  const created = await createRoom(actor, {
    mode: old.mode,
    title: `${baseTitle} · 再来一局`,
    map: old.map,
    serverKey: old.server_key,
    victoryType: old.victory_type || 'kills',
    victoryLimit: old.victory_limit || 10,
    bestOf: old.best_of || 3,
    private: Boolean(Number(old.is_private || 0)),
    passwordHash: old.password_hash || undefined,
  });

  // 新房默认把调用者放在 A 队；如果旧房房主在 B 队，按原队伍修正。
  if (hostMember && hostMember.team === 'b') {
    await q(
      "UPDATE challenge_room_players SET team = 'b' WHERE room_id = ? AND user_id = ?",
      [created.id, callerId]
    );
  }

  const skipped = [];
  for (const member of members) {
    if (member.id === callerId) continue;
    // 条件插入：成员此刻若已进入别的 waiting/live 房间，就跳过，避免一人两房。
    const inserted = await q(
      `INSERT INTO challenge_room_players (room_id, user_id, team, ready)
       SELECT ?, ?, ?, 1 FROM DUAL
        WHERE NOT EXISTS (
          SELECT 1 FROM challenge_room_players p
            JOIN challenge_rooms r ON r.id = p.room_id
           WHERE p.user_id = ? AND r.status IN ('waiting', 'live')
        )`,
      [created.id, member.id, member.team === 'b' ? 'b' : 'a', member.id]
    );
    if (!inserted.affectedRows) skipped.push(member.gameName || member.username);
  }

  const room = await getRoom(created.id, callerId);
  return { room, skipped };
}

module.exports = {
  MODES,
  MODE_SLOTS,
  SPECTATOR_LIMIT,
  getState,
  getRoom,
  listLiveRooms,
  historyOf,
  createRoom,
  joinRoom,
  leaveRoom,
  transferHost,
  closeRoom,
  finishRound,
  rematch,
  invite,
  respond,
  setReady,
  switchTeam,
  startRoom,
  spectatorCount,
  joinSpectate,
  leaveSpectate,
  joinQueue,
  leaveQueue,
  queueList,
  activeChallengesByServer,
  challengeAccess,
  resultOf,
};
